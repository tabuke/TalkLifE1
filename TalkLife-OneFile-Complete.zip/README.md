# TalkLife

React + Vite + Supabase social video app.

## Put files here

- `index.html` -> project root
- `package.json` -> project root
- `.env` -> project root
- `supabase.sql` -> project root (run in Supabase SQL Editor)
- `src/App.jsx` -> ALL main app code is here
- `src/main.jsx` -> React entry
- `public/videos/` -> put the five MP4 files here

## AI video filenames

ai-funny-1.mp4
ai-funny-2.mp4
ai-funny-3.mp4
ai-funny-4.mp4
ai-funny-5.mp4

The repository does not include generated MP4 binaries. Add your own five AI-funny videos using those exact filenames.

## Run

npm install
npm run dev

## Vercel

Framework: Vite
Build command: npm run build
Output directory: dist

Add these Environment Variables in Vercel:
VITE_SUPABASE_URL
VITE_SUPABASE_PUBLISHABLE_KEY
