import { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";

/*
  TALKLIFE — MAIN APP
  This file contains the UI + CSS in one place.

  IMPORTANT:
  Put your Supabase values in .env:
  VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
  VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
*/

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL || "",
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || ""
);

const AI_VIDEOS = [
  {
    id: "ai-1",
    username: "TalkLife AI",
    caption: "When AI tries to understand Nigerian parents 😂🤖",
    video: "/videos/ai-funny-1.mp4"
  },
  {
    id: "ai-2",
    username: "TalkLife AI",
    caption: "AI at a Nigerian wedding 😂",
    video: "/videos/ai-funny-2.mp4"
  },
  {
    id: "ai-3",
    username: "TalkLife AI",
    caption: "When ChatGPT becomes your best friend 😂",
    video: "/videos/ai-funny-3.mp4"
  },
  {
    id: "ai-4",
    username: "TalkLife AI",
    caption: "AI tries to cook jollof rice 😂🍚",
    video: "/videos/ai-funny-4.mp4"
  },
  {
    id: "ai-5",
    username: "TalkLife AI",
    caption: "When your AI assistant knows too much 😂🤖",
    video: "/videos/ai-funny-5.mp4"
  }
];

const css = `
*{box-sizing:border-box}
:root{font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#fff;background:#050505}
body{margin:0;background:#050505}
button,input,textarea{font:inherit}
button{cursor:pointer}
button:disabled{opacity:.55;cursor:not-allowed}
.app{min-height:100vh}
.topbar{height:68px;position:sticky;top:0;z-index:20;display:flex;align-items:center;gap:25px;padding:0 22px;background:rgba(5,5,5,.94);backdrop-filter:blur(18px);border-bottom:1px solid #242424}
.logo{font-size:28px;font-weight:950;letter-spacing:-1.5px;cursor:pointer}
.logo span{color:#ffd21c}
.search{flex:1;max-width:600px;margin:auto}
.search input{width:100%;padding:12px 18px;border-radius:25px;border:1px solid #292929;background:#111;color:#fff;outline:0}
.search input:focus{border-color:#ffd21c}
.top-actions{display:flex;gap:8px}.top-actions button{width:42px;height:42px;border-radius:50%;border:1px solid #292929;background:#111;color:#fff}
.layout{display:flex}.sidebar{position:fixed;top:68px;left:0;width:225px;height:calc(100vh - 68px);padding:22px 13px;border-right:1px solid #242424;background:#070707}
.sidebar button{display:block;width:100%;padding:14px 16px;margin-bottom:5px;border:0;border-radius:12px;background:transparent;color:#ccc;text-align:left;font-weight:750}
.sidebar button:hover,.sidebar button.active{background:rgba(255,210,28,.10);color:#ffd21c}
.content{margin-left:225px;width:100%;max-width:1450px;padding:28px}
.hero{display:flex;align-items:center;justify-content:space-between;gap:20px;padding:30px;border:1px solid #292929;border-radius:24px;background:linear-gradient(135deg,rgba(255,210,28,.13),rgba(85,199,255,.07)),#111;margin-bottom:30px}
.hero h1{margin:0 0 8px;font-size:clamp(26px,4vw,43px)}.hero p{margin:0;color:#aaa}
.primary{border:0;border-radius:12px;padding:13px 20px;background:#ffd21c;color:#000;font-weight:900}
.section-title{display:flex;align-items:center;justify-content:space-between;margin:20px 0 16px}.section-title h2{margin:0}.section-title span{color:#999;font-size:14px}
.video-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(245px,1fr));gap:20px}
.video-card{overflow:hidden;background:#111;border:1px solid #242424;border-radius:18px}
.video-wrap{position:relative;background:#000}.video-wrap video{display:block;width:100%;aspect-ratio:9/14;object-fit:cover;background:#000}
.video-actions{position:absolute;right:9px;bottom:10px;display:flex;flex-direction:column;gap:8px}
.video-actions button{width:43px;height:43px;border:0;border-radius:50%;background:rgba(0,0,0,.75);color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center}
.video-actions button.liked{color:#ff3b30}.video-actions small{font-size:9px}
.video-info{padding:13px}.creator{display:flex;align-items:center;gap:9px}.avatar,.big-avatar{display:grid;place-items:center;border-radius:50%;background:linear-gradient(135deg,#ffd21c,#ff3b30);color:#000;font-weight:950}.avatar{width:34px;height:34px}.video-info p{color:#ddd;line-height:1.4}.ai-label{display:inline-block;padding:4px 8px;border-radius:20px;border:1px solid rgba(85,199,255,.4);color:#55c7ff;font-size:10px;font-weight:850}
.panel{max-width:750px;background:#111;border:1px solid #242424;border-radius:22px;padding:28px}.panel h1{margin-top:0}
.form{display:grid;gap:12px}.form label{color:#aaa;font-size:14px}.form input,.form textarea{width:100%;padding:14px;border:1px solid #292929;border-radius:12px;background:#080808;color:#fff;outline:0}.form textarea{min-height:140px;resize:vertical}
.auth-page{min-height:100vh;display:grid;place-items:center;padding:20px;background:radial-gradient(circle at 50% 20%,rgba(255,210,28,.14),transparent 35%),#050505}
.auth-card{width:min(430px,100%);padding:38px;background:#101010;border:1px solid #292929;border-radius:25px;text-align:center}.auth-card .logo{font-size:40px}.tagline{color:#999;margin:8px 0 28px}.auth-form{display:grid;gap:12px}.auth-form input{width:100%;padding:14px;border:1px solid #292929;border-radius:12px;background:#080808;color:#fff;outline:0}.auth-form button{border:0;border-radius:12px;padding:14px;background:#ffd21c;color:#000;font-weight:900}.switch{margin-top:18px;border:0;background:transparent;color:#ffd21c}
.message{margin-top:15px;padding:12px;border-radius:12px;background:rgba(255,210,28,.08);border:1px solid rgba(255,210,28,.22);color:#ffd21c}
.global-message{margin-bottom:15px}
.profile-header{display:flex;align-items:center;gap:20px;padding:28px;background:#111;border:1px solid #242424;border-radius:22px;margin-bottom:28px}.big-avatar{width:90px;height:90px;font-size:35px}.profile-header h1{margin:0}.muted{color:#999}.stats{display:flex;gap:24px;color:#999}.stats b{color:#fff}
.notification{padding:18px 0;border-bottom:1px solid #242424}
.empty{text-align:center;padding:60px;border:1px dashed #292929;border-radius:18px;color:#999}
.mobile-nav{display:none}
@media(max-width:800px){
.topbar{height:62px;padding:0 13px}.search{display:none}.sidebar{display:none}.content{margin-left:0;padding:18px 12px 88px}.hero{padding:22px;align-items:flex-start;flex-direction:column}.video-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.video-card{border-radius:14px}.video-info{padding:9px}.video-info p{font-size:13px}.mobile-nav{position:fixed;display:flex;z-index:50;bottom:0;left:0;right:0;height:64px;align-items:center;justify-content:space-around;background:rgba(8,8,8,.97);border-top:1px solid #242424}.mobile-nav button{border:0;background:transparent;color:#fff;font-size:21px}.profile-header{padding:20px}.big-avatar{width:70px;height:70px;font-size:28px}.stats{gap:12px;font-size:12px}
}
`;

function Style() {
  useEffect(() => {
    const s = document.createElement("style");
    s.textContent = css;
    document.head.appendChild(s);
    return () => s.remove();
  }, []);
  return null;
}

function VideoCard({ video, onLike }) {
  const [liked, setLiked] = useState(false);
  const [likes, setLikes] = useState(video.likes_count || 0);

  return (
    <article className="video-card">
      <div className="video-wrap">
        <video src={video.video} controls playsInline preload="metadata" />
        <div className="video-actions">
          <button className={liked ? "liked" : ""} onClick={() => {
            setLiked(v => !v);
            setLikes(v => v + (liked ? -1 : 1));
            onLike?.(video);
          }}>❤️<small>{likes}</small></button>
          <button onClick={() => alert("Comments will open here in the next version.")}>💬<small>{video.comments_count || 0}</small></button>
          <button onClick={() => navigator.clipboard?.writeText(location.href)}>🔗</button>
        </div>
      </div>
      <div className="video-info">
        <div className="creator">
          <div className="avatar">{(video.username || "T")[0].toUpperCase()}</div>
          <strong>@{video.username || "talklife"}</strong>
        </div>
        <p>{video.caption}</p>
        <span className="ai-label">🤖 AI CONTENT</span>
      </div>
    </article>
  );
}

export default function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [page, setPage] = useState("home");
  const [videos, setVideos] = useState(AI_VIDEOS);
  const [authMode, setAuthMode] = useState("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session) loadProfile(data.session.user);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      if (s) loadProfile(s.user);
      else setProfile(null);
    });
    loadPosts();
    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadProfile(u) {
    const { data } = await supabase.from("profiles").select("*").eq("id", u.id).maybeSingle();
    setProfile(data || { id:u.id, username:u.email?.split("@")[0] || "user", full_name:"TalkLife User" });
  }

  async function loadPosts() {
    const { data } = await supabase.from("posts").select("*,profiles(username,full_name,avatar_url)").order("created_at",{ascending:false});
    if (!data) return;
    const real = data.map(p => ({
      ...p,
      username:p.profiles?.username || p.profiles?.full_name || "user",
      video:p.media_url
    }));
    setVideos([...real, ...AI_VIDEOS]);
  }

  async function auth(e) {
    e.preventDefault(); setBusy(true); setNotice("");
    try {
      if (authMode === "signup") {
        const username = name.trim().toLowerCase().replace(/[^a-z0-9_]/g,"").slice(0,25) || `user${Date.now()}`;
        const { data, error } = await supabase.auth.signUp({email,password,options:{data:{full_name:name,username}}});
        if (error) throw error;
        if (data.user) await supabase.from("profiles").upsert({id:data.user.id,username,full_name:name,email});
        setNotice("Account created. Check your email if confirmation is enabled.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({email,password});
        if (error) throw error;
      }
    } catch (err) { setNotice(err.message); }
    finally { setBusy(false); }
  }

  async function logout() {
    await supabase.auth.signOut();
    setPage("home");
  }

  async function upload(e) {
    e.preventDefault(); setBusy(true); setNotice("");
    try {
      const file = e.target.video.files[0];
      if (!file) throw new Error("Choose a video first.");
      const ext = file.name.split(".").pop();
      const path = `${session.user.id}/${crypto.randomUUID()}.${ext}`;
      const { error: up } = await supabase.storage.from("videos").upload(path,file);
      if (up) throw up;
      const { data:urlData } = supabase.storage.from("videos").getPublicUrl(path);
      const { error } = await supabase.from("posts").insert({
        user_id:session.user.id,
        caption:e.target.caption.value,
        media_url:urlData.publicUrl,
        media_type:"video"
      });
      if (error) throw error;
      e.target.reset(); await loadPosts(); setNotice("Video published successfully."); setPage("home");
    } catch (err) { setNotice(err.message); }
    finally { setBusy(false); }
  }

  if (!session) return (
    <div className="auth-page">
      <Style/>
      <div className="auth-card">
        <div className="logo">Talk<span>Life</span></div>
        <p className="tagline">Share your life. Discover your world.</p>
        <form className="auth-form" onSubmit={auth}>
          {authMode==="signup" && <input placeholder="Full name" value={name} onChange={e=>setName(e.target.value)} required/>}
          <input type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/>
          <input type="password" placeholder="Password (6+ characters)" value={password} onChange={e=>setPassword(e.target.value)} minLength="6" required/>
          <button disabled={busy}>{busy?"Please wait...":authMode==="login"?"Login":"Create account"}</button>
        </form>
        {notice && <div className="message">{notice}</div>}
        <button className="switch" onClick={()=>{setAuthMode(authMode==="login"?"signup":"login");setNotice("")}}>
          {authMode==="login"?"Create a new account":"Already have an account? Login"}
        </button>
      </div>
    </div>
  );

  const myVideos = videos.filter(v => v.user_id === session.user.id);

  return (
    <div className="app">
      <Style/>
      <header className="topbar">
        <div className="logo" onClick={()=>setPage("home")}>Talk<span>Life</span></div>
        <div className="search"><input placeholder="Search TalkLife..."/></div>
        <div className="top-actions">
          <button onClick={()=>setPage("notifications")}>🔔</button>
          <button onClick={()=>setPage("profile")}>👤</button>
        </div>
      </header>

      <div className="layout">
        <aside className="sidebar">
          {[
            ["home","🏠 Home"],["discover","🔥 Discover"],["upload","➕ Create"],
            ["profile","👤 Profile"],["notifications","🔔 Notifications"]
          ].map(([p,label])=><button key={p} className={page===p?"active":""} onClick={()=>setPage(p)}>{label}</button>)}
          <button onClick={logout}>🚪 Logout</button>
        </aside>

        <main className="content">
          {notice && <div className="message global-message">{notice}</div>}

          {page==="home" && <>
            <section className="hero">
              <div><h1>Welcome to TalkLife 👋</h1><p>Share moments, discover people and enjoy creative videos.</p></div>
              <button className="primary" onClick={()=>setPage("upload")}>Create Video</button>
            </section>
            <div className="section-title"><h2>For You</h2><span>AI & community videos</span></div>
            <div className="video-grid">{videos.map(v=><VideoCard key={v.id} video={v}/>)}</div>
          </>}

          {page==="discover" && <>
            <div className="section-title"><h2>Discover</h2><span>Trending on TalkLife</span></div>
            <div className="video-grid">{videos.map(v=><VideoCard key={v.id} video={v}/>)}</div>
          </>}

          {page==="upload" && <div className="panel">
            <h1>Create a video</h1><p className="muted">Upload a video to your TalkLife profile.</p>
            <form className="form" onSubmit={upload}>
              <label>Video</label><input name="video" type="file" accept="video/*" required/>
              <label>Caption</label><textarea name="caption" placeholder="What's happening?" required/>
              <button className="primary" disabled={busy}>{busy?"Uploading...":"Publish Video"}</button>
            </form>
          </div>}

          {page==="profile" && <div>
            <div className="profile-header">
              <div className="big-avatar">{(profile?.username||"U")[0].toUpperCase()}</div>
              <div><h1>{profile?.full_name||"TalkLife User"}</h1><p className="muted">@{profile?.username||"user"}</p>
              <div className="stats"><span><b>{myVideos.length}</b> Videos</span><span><b>0</b> Followers</span><span><b>0</b> Following</span></div></div>
            </div>
            <div className="section-title"><h2>Your Videos</h2></div>
            {myVideos.length ? <div className="video-grid">{myVideos.map(v=><VideoCard key={v.id} video={v}/>)}</div> : <div className="empty">You haven't posted a video yet.</div>}
          </div>}

          {page==="notifications" && <div className="panel">
            <h2>Notifications</h2>
            <div className="notification">❤️ Welcome to TalkLife</div>
            <div className="notification">🤖 AI videos are available</div>
            <div className="notification">🎉 Start sharing your first video</div>
          </div>}
        </main>
      </div>

      <nav className="mobile-nav">
        <button onClick={()=>setPage("home")}>🏠</button>
        <button onClick={()=>setPage("discover")}>🔥</button>
        <button onClick={()=>setPage("upload")}>➕</button>
        <button onClick={()=>setPage("notifications")}>🔔</button>
        <button onClick={()=>setPage("profile")}>👤</button>
      </nav>
    </div>
  );
}
