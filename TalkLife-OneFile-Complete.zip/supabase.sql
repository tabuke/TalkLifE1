create extension if not exists "uuid-ossp";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  full_name text,
  email text,
  avatar_url text,
  bio text default '',
  followers_count integer default 0,
  following_count integer default 0,
  created_at timestamptz default now()
);

create table if not exists public.posts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  caption text default '',
  media_url text not null,
  media_type text default 'video',
  likes_count integer default 0,
  comments_count integer default 0,
  shares_count integer default 0,
  created_at timestamptz default now()
);

create table if not exists public.likes (
  id uuid primary key default uuid_generate_v4(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  unique(post_id,user_id)
);

create table if not exists public.comments (
  id uuid primary key default uuid_generate_v4(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  comment text not null,
  created_at timestamptz default now()
);

create table if not exists public.follows (
  id uuid primary key default uuid_generate_v4(),
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  unique(follower_id,following_id),
  check(follower_id<>following_id)
);

create table if not exists public.notifications (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete cascade,
  type text not null,
  message text not null,
  read boolean default false,
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.follows enable row level security;
alter table public.notifications enable row level security;

drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select using (true);
drop policy if exists profiles_insert on public.profiles;
create policy profiles_insert on public.profiles for insert with check(auth.uid()=id);
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update using(auth.uid()=id) with check(auth.uid()=id);

drop policy if exists posts_read on public.posts;
create policy posts_read on public.posts for select using (true);
drop policy if exists posts_insert on public.posts;
create policy posts_insert on public.posts for insert with check(auth.uid()=user_id);
drop policy if exists posts_update on public.posts;
create policy posts_update on public.posts for update using(auth.uid()=user_id);
drop policy if exists posts_delete on public.posts;
create policy posts_delete on public.posts for delete using(auth.uid()=user_id);

drop policy if exists likes_read on public.likes;
create policy likes_read on public.likes for select using (true);
drop policy if exists likes_insert on public.likes;
create policy likes_insert on public.likes for insert with check(auth.uid()=user_id);
drop policy if exists likes_delete on public.likes;
create policy likes_delete on public.likes for delete using(auth.uid()=user_id);

drop policy if exists comments_read on public.comments;
create policy comments_read on public.comments for select using (true);
drop policy if exists comments_insert on public.comments;
create policy comments_insert on public.comments for insert with check(auth.uid()=user_id);
drop policy if exists comments_delete on public.comments;
create policy comments_delete on public.comments for delete using(auth.uid()=user_id);

drop policy if exists follows_read on public.follows;
create policy follows_read on public.follows for select using (true);
drop policy if exists follows_insert on public.follows;
create policy follows_insert on public.follows for insert with check(auth.uid()=follower_id);
drop policy if exists follows_delete on public.follows;
create policy follows_delete on public.follows for delete using(auth.uid()=follower_id);

drop policy if exists notifications_read on public.notifications;
create policy notifications_read on public.notifications for select using(auth.uid()=user_id);
drop policy if exists notifications_update on public.notifications;
create policy notifications_update on public.notifications for update using(auth.uid()=user_id);

insert into storage.buckets(id,name,public)
values('videos','videos',true)
on conflict(id) do update set public=true;

drop policy if exists videos_read on storage.objects;
create policy videos_read on storage.objects for select using(bucket_id='videos');

drop policy if exists videos_upload on storage.objects;
create policy videos_upload on storage.objects for insert to authenticated
with check(bucket_id='videos' and (storage.foldername(name))[1]=auth.uid()::text);

drop policy if exists videos_delete on storage.objects;
create policy videos_delete on storage.objects for delete to authenticated
using(bucket_id='videos' and owner_id=auth.uid()::text);
